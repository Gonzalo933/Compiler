#ifndef TABLA_SIMBOLOS_H
#define TABLA_SIMBOLOS_H
#include "vector.h"

typedef struct {
	vector *tablaGlobal;
	vector *tablaLocal;
	int local;
} TablaSimbolos;

typedef struct {
	char identificador[100];
	int tipo;
} resultado;

/* Puntero vacio a tabla de simbolos */
int creaTablaSimbolos(TablaSimbolos **tabla);
//int creaTablaSimbolos(TablaSimbolos *);

/* Buscamos en la tabla el elemento con el identificador pasado y lo devolvemos en resultado. 
¡OJO! Resultado tiene que estar reservado previamente */
int buscarTablaSimbolos(TablaSimbolos *, char *, resultado *);

int insertarTablaSimbolos(TablaSimbolos*, informacion_semantica *);



#endif
