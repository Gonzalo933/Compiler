#include <stdio.h>   
#include <stdlib.h>
#include <string.h>

#include "lista.h"
#include "informacion_semantica.h"
 
node *list_add(node **p, informacion_semantica *i) {
    node *n = (node *)malloc(sizeof(node));
    if (n == NULL)
        return NULL;
    n->next = *p;                                                                            
    *p = n;
    n->data = i;
    return n;
}
 
void list_remove(node **p) { 
    if (*p != NULL) {
        node *n = *p;
        *p = (*p)->next;
        free(n);
    }
}
 
node **list_search(node **n, informacion_semantica *i) {
    while (*n != NULL) {
        if (!strcmp((*n)->data->identificador, i->identificador)) {
            return n;
        }
        n = &(*n)->next;
    }
    return NULL;
}
 
void list_print(node *n) {
    while (n != NULL) {
        printf("%s -> ", n->data->identificador);
        n = n->next;
    }
    if (n == NULL) {
        printf("NULL\n");
    }
    
}

