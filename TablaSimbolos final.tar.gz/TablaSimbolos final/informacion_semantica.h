#ifndef _INFORMACION_SEMANTICA_
#define _INFORMACION_SEMANTICA_

#define MAXID 100

typedef enum categoria_var {VAR_LOCAL,VAR_GLOBAL,PARAM,FUNCION} CATEGORIAS;
typedef enum tipo_basico {BOOL,INT,PILA} TIPOS;

typedef struct semantica{
	char identificador[MAXID];

	CATEGORIAS categoria;
	TIPOS tipo;

	int num_parametros; /* Solo para categoria = FUNCION */
	int num_variables_locales; /* Solo para categoria = FUNCION */

	int num_parametros_definicion; /* Solo para categoria = PARAMETRO */
	int pos_parametro; /* Solo para categoria = PARAMETRO */

	int pos_variable_local; /* Solo para categoria = VAR_LOCAL */

	int capacidad; /* Solo para tipo = PILA, maximo = 64 */

	int inicializada; /* 0 o 1 */
} informacion_semantica;
	
#endif
