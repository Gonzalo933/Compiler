#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "tabla_simbolos.h"
#include "informacion_semantica.h"
#include "lista.h"
#include "vector.h"


int main (){

	TablaSimbolos *tabla=NULL;
	resultado *res = (resultado *)malloc(sizeof(resultado));
	informacion_semantica inf1, inf2, inf3, inf4, inf5, inf6, inf7, inf8, inf9;	
	
	if(creaTablaSimbolos(&tabla)!=0){
		printf("Tabla no creada\n");
		return -1;
	}
	else printf("Tabla creada\n");

   //categoria funcion
	strcpy (inf1.identificador, "Variable");
	inf1.tipo = 1;
	strcpy (inf2.identificador, "Integer");
	inf2.tipo = 0;
   strcpy (inf3.identificador, "Asdf");
	inf3.tipo = 0;
	strcpy (inf4.identificador, "lol");
	inf4.tipo = 0;
	strcpy (inf5.identificador, "qwerty");
	inf5.tipo = 0;
	
	strcpy (inf6.identificador, "uno");
	inf6.tipo = 2;
//	strcpy (inf7.identificador, "dos");
//	inf7.tipo = 0;
   strcpy (inf7.identificador, "cierre");
   inf7.tipo = -999;
	strcpy (inf8.identificador, "tres");
	inf8.tipo = 0;
	strcpy (inf9.identificador, "cuatro");
	inf9.tipo = 1;
	
	
	//No lo encuentras
	printf("\n--Buscar antes de insertar----\n");
	buscarTablaSimbolos(tabla, inf1.identificador, res);
   printf("Tipo: %d \n", res->tipo);
	printf("Nombre: %s \n", res->identificador);

	
	/*Insertar en tabla global*/
   /*Se inserta al principio de la lista siempre*/
   insertarTablaSimbolos(tabla, &inf1);
   insertarTablaSimbolos(tabla, &inf2);
   insertarTablaSimbolos(tabla, &inf3);
   insertarTablaSimbolos(tabla, &inf4);
   insertarTablaSimbolos(tabla, &inf4);
   insertarTablaSimbolos(tabla, &inf5);
   
   /*Insertar en tabla local*/
   tabla->local=1;
   insertarTablaSimbolos(tabla, &inf6);
//   insertarTablaSimbolos(tabla, &inf7); //cierre
   insertarTablaSimbolos(tabla, &inf8);
   insertarTablaSimbolos(tabla, &inf9);

   /*Lo encuentras*/
   printf("\n--Buscar despues de insertar----\n");
	buscarTablaSimbolos(tabla, inf1.identificador, res);
   printf("Tipo: %d \n", res->tipo);
	printf("Nombre: %s \n", res->identificador);
	

/*
	//Buscar antes de insertar, no encuentra nada
	buscarTablaSimbolos(tabla, inf1.identificador, res); 
   printf("Tipo: %d \n", res->tipo);
	printf("Nombre: %s \n", res->identificador);
	
	buscarTablaSimbolos(tabla, inf2.identificador, res);
   printf("Tipo: %d \n", res->tipo);
	printf("Nombre: %s \n", res->identificador);
	
	buscarTablaSimbolos(tabla, "cierre", res);
	printf("Tipo: %d \n", res->tipo);
	printf("Nombre: %s \n", res->identificador);
	
	//Insertar
	insertarTablaSimbolos(tabla, &inf1);
	insertarTablaSimbolos(tabla, &inf2);
   insertarTablaSimbolos(tabla, &inf3);
	
   //Buscar despues de insertar, encuentra los simbolos
	buscarTablaSimbolos(tabla, inf1.identificador, res);
   printf("Tipo: %d \n", res->tipo);
	printf("Nombre: %s \n", res->identificador);
	
	buscarTablaSimbolos(tabla, inf2.identificador, res);
   printf("Tipo: %d \n", res->tipo);
	printf("Nombre: %s \n", res->identificador);	
		
	buscarTablaSimbolos(tabla, "cierre", res);
   printf("Tipo: %d \n", res->tipo);
	printf("Nombre: %s \n", res->identificador);
*/

   /*Imprimir*/
   printf("\n*Tabla Simbolos Global*   -TAMVECTOR: %d\n", TAMVECTOR);
	imprimeVector(tabla->tablaGlobal);
	printf("\n*Tabla Simbolos Local*    -TAMVECTOR: %d\n", TAMVECTOR);
	imprimeVector(tabla->tablaLocal);
	
	/*Si queremos cerrar un ambito, la tabla local se borra. Salimos de la funcion. */
	printf("\n\n\n--CASO CIERRE de AMBITO--\n");
	inf7.inicializada=-999;
	if(insertarTablaSimbolos(tabla, &inf7)==-1)
			return -1;
	
	printf("\n*Tabla Simbolos Global*   -TAMVECTOR: %d\n", TAMVECTOR);
	imprimeVector(tabla->tablaGlobal);
	printf("\n*Tabla Simbolos Local*    -TAMVECTOR: %d\n", TAMVECTOR);
	imprimeVector(tabla->tablaLocal); //Deberia estar vacia
	
	//buscar cierre no aparece
   //buscarTablaSimbolos(tabla, inf8.identificador, res);
   //printf("Tipo: %d \n", res->tipo);
	//printf("Nombre: %s \n", res->identificador);

   //Liberar recursos	
	free(res);
	free(tabla);
	
	return 0;
}
