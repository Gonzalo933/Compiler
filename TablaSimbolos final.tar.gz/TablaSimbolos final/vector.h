#ifndef Vector
#define Vector

#define TAMVECTOR 10
#include "lista.h"
#include "informacion_semantica.h"

typedef struct {
	node *vect[TAMVECTOR];
} vector;

/* Crear vector */
vector *creaVector();

/* Borrar vector */
void borraVector(vector *);

/* Insertar en el vector */
int insVector(informacion_semantica *, vector *);

/* Funcion hash */
int funHash(informacion_semantica *);

/* Buscar vector */
node *buscVector(informacion_semantica, vector *);

/* imprimir el vector */
void imprimeVector(vector *);


#endif
