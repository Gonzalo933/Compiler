#ifndef _LISTA_H_
#define _LISTA_H_

#include "informacion_semantica.h"

typedef struct ns {
        informacion_semantica *data;
        struct ns *next;
} node;

#include <stdio.h>   
#include <stdlib.h>

/* Añadir un nodo 
 * n: lista donde meteremos el nodo
 * i: información del nodo 
 * return: puntero al nodo nuevo de la lista */
node *list_add(node **p, informacion_semantica *i);

/* elimina el nodo indicado en la lista
 * p: puntero al nodo a eliminar */
void list_remove(node **p);

/* buscar un nodo 
 * i: información que tiene el nodo que buscamos 
 * n: lista donde lo queremos buscar
 * return: puntero al nodo buscado */
node **list_search(node **n, informacion_semantica *i);

/* imprimir una lista */
void list_print(node *n);

#endif
