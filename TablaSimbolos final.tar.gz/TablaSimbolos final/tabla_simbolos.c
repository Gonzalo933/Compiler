#include "tabla_simbolos.h"
#include <string.h>

/* Puntero vacio a tabla de simbolos */
int creaTablaSimbolos(TablaSimbolos **tabla)
{
	if((*tabla)!=NULL)
		return -1;

	/* Reservamos los punteros a vector */
	*tabla=(TablaSimbolos *)malloc(2*sizeof(vector *)+sizeof(int));

	/* Creamos los vectores dentro de la tabla */
	(*tabla)->tablaGlobal=creaVector();
	(*tabla)->tablaLocal=creaVector();
	(*tabla)->local=0;

	return 0;
}

/* Buscamos en la tabla el elemento con el identificador pasado y lo devolvemos en resultado. 
¡OJO! Resultado tiene que estar reservado previamente */
int buscarTablaSimbolos(TablaSimbolos *tabla, char *identificador, resultado *res)
{
	node *temp;
	informacion_semantica elementoBuscado;
	strcpy(elementoBuscado.identificador,identificador);

	/* Comprobamos los parametros pasados */
	if(tabla==NULL || identificador==NULL || res==NULL)
		return -1;

	/* Primero buscamos en la tabla local */
	//if((temp=buscVector(elementoBuscado, tabla->tablaLocal->vect[0]))!=NULL) TAMVECTOR
	//if((temp=buscVector(elementoBuscado, tabla->tablaLocal->vect[TAMVECTOR-1]))!=NULL) 
	if((temp=buscVector(elementoBuscado, tabla->tablaLocal))!=NULL) 
	{
		strcpy(res->identificador,temp->data->identificador);
		res->tipo=temp->data->tipo;
		return 0;
	}

	/* Si no lo encontramos en la local probamos en la global */
	/* Busqueda en la tabla global */
	//if((temp=buscVector(elementoBuscado, tabla->tablaGlobal->vect[0]))!=NULL)
	//if((temp=buscVector(elementoBuscado, tabla->tablaGlobal->vect[TAMVECTOR-1]))!=NULL)
	if((temp=buscVector(elementoBuscado, tabla->tablaGlobal))!=NULL) 
	{
		strcpy(res->identificador,temp->data->identificador);
		res->tipo=temp->data->tipo;
		return 0;
	}

	return -1;

}

/* La funcion se encargara de saber si es un ambito (funcion) u otra cosa comparando el campo categoria con FUNCION */ 
int insertarTablaSimbolos(TablaSimbolos*tabla, informacion_semantica *inf)
{
	resultado temp;

	if(tabla==NULL || inf==NULL)
		return -1;

	/* IMPORTANTE */
	/* Si queremos cerrar un ambito, el campo inicializada de inf ha de valer -999 y tener el identificador cierre */
	if(strcmp(inf->identificador, "cierre")==0 && inf->inicializada==(-999))
	{
		borraVector(tabla->tablaLocal);
		tabla->tablaLocal=creaVector();
		return 0;
	}

	/* Primero buscamos el simbolo. Si lo encontramos, error */
	if(buscarTablaSimbolos(tabla, inf->identificador, &temp)==0)
		return -1;

	/* Comprobamos si es un ambito lo que queremos insertar */
	if(inf->categoria==FUNCION)
	{
		if(insVector(inf, tabla->tablaLocal)==-1)
			return -1;
		if(insVector(inf, tabla->tablaGlobal)==-1)
			return -1;
		tabla->local=1;
	}
	else
	{
		if(tabla->local==1)
		{
			if(insVector(inf, tabla->tablaLocal)==-1)
				return -1;
		}
		else
		{
			if(insVector(inf, tabla->tablaGlobal)==-1)
				return -1;
		}
	}

	return 0;

}


