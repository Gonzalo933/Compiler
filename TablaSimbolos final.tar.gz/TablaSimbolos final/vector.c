#include "vector.h"
#include <stdio.h>
#include <string.h>

/* Crear vector */
vector *creaVector()
{
	vector *vec;
	
	vec = (vector*) calloc(1,sizeof(vector));
	if(!vec)
	   return NULL;
	   
	   /*
	for(i=0;i<TAMVECTOR;i++)
	{
	   //vec->vect[i] = calloc(1,sizeof(node));
	   //node *list_add(node **p, informacion_semantica *i) {
	   if( (vec->vect[i] = list_add(&aux, calloc(1,sizeof(informacion_semantica)))) == NULL )
	   {
	      i--;
	      for(;i>=0;i--)
	      {
	         free(vec->vect[i]->data);
	         free(vec->vect[i]);
         }
	         
	      free(vec);
	      return NULL;
      }
      else
         aux = vec->vect[i];
   }
   */
	
	return vec;
}

/* Borrar vector */
void borraVector(vector *vec){
	free(vec);
}

/* Insertar en el vector */
int insVector(informacion_semantica *clave, vector *vec){
	int posicion;
	/* Buscamos su posicion en la tabla */
	posicion=funHash(clave);
	
	
	printf("Posicion hash: %d\n", posicion);

	/* Intentamos añadir en la tabla */
	if((vec->vect[posicion] = list_add(&(vec->vect[posicion]), clave))==NULL)
	{
		printf("Error añadiendo en la lista\n");
		return -1;
	}
	return 0;
	
}

/* Funcion hash 
 * La función se basa en sumar el valor
 * de todos los caracteres del identificador */
int funHash(informacion_semantica *node){
	int indiceFinal=0, i;

	if(node==NULL)
		return -1;

	for(i=0; i<strlen(node->identificador);i++)
	{
		indiceFinal+=(int)node->identificador[i];
	}
	indiceFinal=indiceFinal%TAMVECTOR;
	return indiceFinal;

}

/* Buscar vector */
//node *buscVector(informacion_semantica inf, node *lista)
node *buscVector(informacion_semantica inf, vector *lista)
{
	int posicion=0;
	/* Buscamos su posicion en la tabla */
	posicion=funHash(&inf);
	node *aux = lista->vect[posicion];
	
   node **n = list_search(&aux, &inf);
   if(n == NULL)
      return NULL;
      
   return *n;
}

void imprimeVector(vector *v){
	int i;
	for (i=0; i<TAMVECTOR; i++){
		list_print(v->vect[i]);
	}
}

